let boton;
let campoTexto;
let mensaje = "Escribe algo y precina un boton";

function setup() {

  createCanvas(300, 200);
 
 
  campoTexto = createInput('');
  campoTexto.position(20, 50);
 
  boton = createButton('Procesar');
  boton.position(180, 50);
 
  boton.mousePressed(procesarDato);
}

function draw() {
 
  background(237, 232, 78);
 
  fill(0);
  textSize(16);
  text("Mision 3: Interfaz grafica sencilla", 20, 40);
 
  textSize(17);
  fill(73, 163, 60);
  text(mensaje, 20, 120);
}

function procesarDato() {
  let valor = campoTexto.value();
 
  if (valor === "") {
    mensaje = "Por favor, ingresa un texto primero.";
  } else {
    mensaje = "Dato recibido correctamente: " + valor;
  }
}
